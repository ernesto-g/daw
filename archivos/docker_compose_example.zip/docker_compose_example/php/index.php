<!DOCTYPE html>
<html>
    <head>
        <title>PHP-MySQL</title>
    </head>
    <body>
        <h1>Connection PHP Webapp and MySQL</h1>
        <h3>Date: <?= date('l \t\h\e jS') ?></h3>
        <h3>Timestamp:  <?php $t=time(); echo($t);?></h3>
        <?php
            $servername = "mysql-server";
            $username = "root";
            $password = "userpass";
            // Create connection
            $conn = new mysqli($servername, $username, $password);
            // Check connection
            if ($conn->connect_error) {
                echo "Connetion to MySQL failed";
            } else {
                echo "Connetion to MySQL succed";
            }
            // Close DB connection
            $conn->close();
        ?>
    </body>
</html>